# Rassegna Flash Debug

Questa versione include log di debug per capire meglio cosa succede durante l'esecuzione.

## Categorie incluse
- Politica internazionale (Il Post, Internazionale, Politico, Foreign Affairs)
- AI e Tech (MIT Tech Review, The Verge, NYT Technology)
- Antropologia e Scienze sociali (Scientific American, Sage, Cambridge)

### Come funziona
1. Ogni giorno all'orario configurato nel workflow (`07:00 ora italiana`).
2. Scarica e riassume articoli delle ultime 24h.
3. Salva un file `.txt` negli artifact e lo invia su Telegram.

